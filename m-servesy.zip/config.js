var config = {};

config.BASE_URL = 'http://api.servesy.com/';
export default config;
