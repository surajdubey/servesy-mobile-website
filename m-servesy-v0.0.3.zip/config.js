var config = {};

// config.BASE_URL = 'http://localhost:3000/';
config.BASE_URL = 'http://api.servesy.com/';
export default config;
